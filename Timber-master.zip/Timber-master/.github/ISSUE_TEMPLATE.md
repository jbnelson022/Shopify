## Deprecation warning ⚠️

The Timber theme is no longer being maintained by Shopify.  Issues will not be addressed by this
repo's owners.

Developers are encouraged to check out [Slate](https://github.com/Shopify/slate) - a theme scaffolding and command line tool built for developing Shopify themes.
